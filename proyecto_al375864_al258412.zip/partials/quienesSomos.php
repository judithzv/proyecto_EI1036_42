<main>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div id="container">
<div id="mincontainer">
	<h3>Buenas! Somos Judith Zorío Ventura y Núria Moreno Chamorro, alumnas de la Universidad Jaume I de Castellón, esta es nuestra web de la asignatura EI1036_42 
        y consiste en una tienda de instrumentos musicales.</h3>
</div>
</div>
</main>