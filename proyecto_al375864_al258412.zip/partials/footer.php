
<footer>
	<p>
	<img src="https://licensebuttons.net/l/by-sa/3.0/88x31.png" height="31px" /><br/>
	<time datetime="2020-10-22">2020</time>.</p>
	</p>
	<address>
		<p class="izq"> Written by
			<a href="mailto:al375864@uji.es" rev="author">Núria</a> y <a href="mailto:al258412@uji.es"> Judith </a></p>
		<p class="der"> Visit us at:12006 UJI </p>
	</address>
</footer>
</body>

</html>