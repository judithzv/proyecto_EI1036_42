<main>
	<nav>
		<a href="./portal.php?action=info" id="nm"><i class="fa fa-info-circle" aria-hidden="true"></i></a>
		<a href="?action=home" id="nm"><i class="fa fa-home" aria-hidden="true"></i></a>
        <a href="?action=registro" id="nm"><i class="fa fa-user-plus" aria-hidden="true"></i></a>
		<a href="?action=login" id="lnm"><i class="fa fa-sign-in" aria-hidden="true"></i></a>
	</nav>
	<nav id="margen"></nav>
</main>
