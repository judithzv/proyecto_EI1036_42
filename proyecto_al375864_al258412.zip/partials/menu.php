<main>
<nav>
	<ul>
		<li>
			<a href="./portal.php?action=home" id="l"><i class="fa fa-info-circle" aria-hidden="true"></i></a>
		</li>
		<li>
			<a href="?action=registro" id="l"><i class="fa fa-user-plus" aria-hidden="true"></i></a>
		</li>
		<li>
			<a href="?action=login" id="l"><i class="fa fa-sign-in" aria-hidden="true"></i></a>
		</li>
		<li>
			<a href="?action=productos" id="l"><i class="fa fa-home" aria-hidden="true"></i></a>
		</li>
		<li>
			<a href='?action=carrito' id='l'><i class="fa fa-shopping-cart"></i></a>
		</li>
		<li>
			<a href='?action=carrito' id='l'><i class="fa fa-credit-card" aria-hidden="true"></i></i></a>
		</li>

	</ul>
</nav>
</main>
