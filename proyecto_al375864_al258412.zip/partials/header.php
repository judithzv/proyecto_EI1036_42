<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<title>Tienda de música</title>
	<META name="Author" content="Núria Moreno Chamorro y Judith Zorío Ventura">
	<link rel="stylesheet" href="./css/estilo.css" type="text/css">
	<link rel="stylesheet" href="./css/bootstrap-alerts.css" type="text/css">
	<link rel='stylesheet' href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>


<body>
	<header>
		<div class="cabecera">
		<img src="./img/fondo2.gif" id="logotipo" />
		<div class="container-titles">
        <h2> Instrumentalia</h2>
		<p> Tienda profesional de instrumentos musicales </p>
		</div>
		</div>

		<!--
		<img src="./img/fondo2.gif" id="logo" alt="logo" />
		<b><p id="eslogan">Instrumentalia</p></b>
		<br>
		<b><p id="subtitle">Tienda profesional de instrumentos musicales</p></b>
		<br><br><br><br>
		-->
	</header>